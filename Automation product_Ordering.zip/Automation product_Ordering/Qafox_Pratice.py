import time

from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select

obj_service=Service("D:\Automation drivers\chromedriver_win32\chromedriver.exe")
driver=webdriver.Chrome(service=obj_service)

driver.get("https://tutorialsninja.com/demo/index.php?route=common/home")
driver.maximize_window()
driver.implicitly_wait(5)

driver.find_element(By.XPATH,"//a[@title='My Account']").click()
# driver.find_element(By.LINK_TEXT,"Register").click()
driver.find_element(By.LINK_TEXT,"Login").click()

#Reg page
# driver.find_element(By.XPATH,"//input[@id='input-firstname']").send_keys("Soumik")
# driver.find_element(By.XPATH,"//input[@id='input-lastname']").send_keys("Hasan")
# driver.find_element(By.XPATH,"//input[@id='input-email']").send_keys("Soumik178@gmail.com")
# driver.find_element(By.XPATH,"//input[@id='input-telephone']").send_keys("01303104035")
# driver.find_element(By.ID,"input-password").send_keys("123456")
# driver.find_element(By.ID,"input-confirm").send_keys("123456")
# driver.find_element(By.XPATH,"//input[@name='agree']").click()
# driver.find_element(By.XPATH,"//input[@value='Continue']").click()
# driver.find_element(By.XPATH,"//i[@class='fa fa-home']").click()


#LOG in Page

driver.find_element(By.XPATH,"//input[@id='input-email']").send_keys("soumikhsn178@gmail.com")
driver.find_element(By.XPATH,"//input[@id='input-password']").send_keys("123456")
driver.find_element(By.XPATH,"//input[@value='Login']").click()


#ordering items
mouse=ActionChains(driver)
leptops = driver.find_element(By.XPATH,"//a[normalize-space()='Laptops & Notebooks']")
all_leptops = driver.find_element(By.XPATH,"//a[normalize-space()='Show AllLaptops & Notebooks']")
mouse.move_to_element(leptops).move_to_element(all_leptops).click().perform()

driver.find_element(By.XPATH,"//div[@class='caption']//a[contains(text(),'HP LP3065')]").click()

driver.find_element(By.XPATH,"//i[@class='fa fa-calendar']").click()
driver.find_element(By.XPATH,"//th[@class='picker-switch']").click()

year = driver.find_elements(By.XPATH,"//th[@class='picker-switch']")
month = driver.find_elements(By.XPATH,"//body[1]/div[4]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[1]/span")

for m in month:
    if m.text=="Mar":
        m.click()
        break

day=driver.find_elements(By.XPATH,"//tbody//tr//td[@class='day']")
for d in day:
    if d.text=="25":
        d.click()
        break

driver.find_element(By.XPATH,"/html/body/div[2]/div/div/div/div[2]/div[2]/div[2]/input[1]").send_keys("2")
driver.find_element(By.XPATH,"//*[@id='button-cart']").click()

driver.find_element(By.XPATH,"//button[@class='btn btn-inverse btn-block btn-lg dropdown-toggle']").click()
driver.find_element(By.XPATH,"//strong[normalize-space()='Checkout']").click()




driver.find_element(By.XPATH,"//label[normalize-space()='I want to use a new address']//input[@name='payment_address']").click()

#Billing
driver.find_element(By.XPATH,"//input[@id='input-payment-firstname']").send_keys("Soumik")
driver.find_element(By.XPATH,"//input[@id='input-payment-lastname']").send_keys("Hasan")
driver.find_element(By.XPATH,"//input[@id='input-payment-address-1']").send_keys("Mirpur")
driver.find_element(By.XPATH,"//input[@id='input-payment-city']").send_keys("Dhaka")
driver.find_element(By.XPATH,"//input[@id='input-payment-postcode']").send_keys("1216")

country_ele = driver.find_element(By.XPATH,"//select[@id='input-payment-country']")
country = Select(country_ele)
country.select_by_visible_text("Bangladesh")

city_ele=driver.find_element(By.XPATH,"//select[@id='input-payment-zone']")
city = Select(city_ele)
city.select_by_visible_text("Rajshahi")

driver.find_element(By.XPATH,"//input[@id='button-payment-address']").click()
driver.find_element(By.XPATH,"//input[@id='button-shipping-address']").click()
driver.find_element(By.XPATH,"//textarea[@name='comment']").send_keys("Check the product properly")
driver.find_element(By.XPATH,"//input[@id='button-shipping-method']").click()
driver.find_element(By.XPATH,"//input[@name='agree' or  @type='checkbox']").click()
driver.find_element(By.XPATH,"//input[@id='button-payment-method']").click()
driver.find_element(By.XPATH,"//input[@id='button-confirm']").click()


time.sleep(5)