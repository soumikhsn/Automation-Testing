In this project I have written test scripts for a demo website

Covered: Registration | Log in | Add to cart | Review | Confirm Order 